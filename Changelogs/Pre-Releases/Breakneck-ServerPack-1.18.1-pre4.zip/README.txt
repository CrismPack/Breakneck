The server requires 'Java 17' to run.

If you want to use Bukkit plugins you can download the 'Cardboard' mod.